import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from app.services.supabase_client import supabase
from app.data.initial_content import initial_content

def seed_database():
    try:
        # Create the islamic_content table if it doesn't exist
        table_name = 'islamic_content'

        print(f"Starting to seed {table_name} table...")

        # Insert each piece of content
        for content in initial_content:
            try:
                # Remove async/await since we've updated the client
                result = supabase.insert_content(
                    table_name,
                    {
                        'content_type': content['content_type'],
                        'topic': content['topic'],
                        'title': content['title'],
                        'content': content['content'],
                        'source': content['source'],
                        'reference': content['reference'],
                        'scholar': content['scholar']
                    }
                )
                print(f"Successfully inserted content: {content['title']}")
            except Exception as e:
                print(f"Error inserting content {content['title']}: {str(e)}")
                continue

        print("Database seeding completed successfully!")

    except Exception as e:
        print(f"Error seeding database: {str(e)}")

if __name__ == "__main__":
    seed_database()
