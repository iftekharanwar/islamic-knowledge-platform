from typing import List, Dict, Optional
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
from app.services.supabase_client import supabase
import re

class AIService:
    def __init__(self):
        self.model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')
        self.content_cache = {}
        self.embedding_cache = {}

    async def initialize(self):
        await self._load_content()

    async def _load_content(self):
        try:
            result = await supabase.get_content('islamic_content')
            self.content_cache = {item['id']: item for item in result}

            for content_id, content in self.content_cache.items():
                text = f"{content['title']} {content['content']}"
                self.embedding_cache[content_id] = self.model.encode(text)

            print(f"Loaded {len(self.content_cache)} Islamic texts and generated embeddings")
        except Exception as e:
            print(f"Error loading content: {str(e)}")
            raise

    def _preprocess_query(self, query: str) -> str:
        islamic_terms = {
            r'\b(salah|salat|prayer)\b': 'salah',
            r'\b(zakat|zakah)\b': 'zakat',
            r'\b(hajj|pilgrimage)\b': 'hajj',
            r'\b(sawm|siyam|fasting)\b': 'sawm',
            r'\b(quran|koran)\b': 'quran',
            r'\b(hadith|hadeeth)\b': 'hadith'
        }

        processed_query = query.lower()
        for pattern, replacement in islamic_terms.items():
            processed_query = re.sub(pattern, replacement, processed_query, flags=re.IGNORECASE)

        return processed_query

    def find_relevant_content(self, query: str, top_k: int = 3) -> List[Dict]:
        try:
            processed_query = self._preprocess_query(query)
            query_embedding = self.model.encode(processed_query)

            similarities = []
            for content_id, content_embedding in self.embedding_cache.items():
                score = cosine_similarity(
                    [query_embedding],
                    [content_embedding]
                )[0][0]
                similarities.append((content_id, score))

            similarities.sort(key=lambda x: x[1], reverse=True)

            results = []
            for content_id, score in similarities[:top_k]:
                content = self.content_cache[content_id]
                results.append({
                    **content,
                    'relevance_score': float(score)
                })

            return results
        except Exception as e:
            print(f"Error finding relevant content: {str(e)}")
            return []

    async def generate_response(self, query: str, context: List[Dict] = None) -> Dict:
        try:
            relevant_content = context if context else self.find_relevant_content(query)

            if not relevant_content:
                return {
                    "answer": "I apologize, but I couldn't find specific information to answer your question accurately. Please rephrase or ask about a different Islamic topic.",
                    "confidence": 0.0,
                    "references": []
                }

            best_match = relevant_content[0]

            references = []
            for content in relevant_content:
                ref = {
                    "type": content.get('content_type', ''),
                    "source": content.get('source', ''),
                    "reference": content.get('reference', ''),
                    "scholar": content.get('scholar', '')
                }
                references.append(ref)

            return {
                "answer": best_match.get('content', ''),
                "confidence": best_match.get('relevance_score', 0.0),
                "references": references,
                "source_type": best_match.get('content_type')
            }
        except Exception as e:
            print(f"Error generating response: {str(e)}")
            return {
                "answer": "I apologize, but I encountered an error while processing your question about Islamic knowledge.",
                "confidence": 0.0,
                "references": []
            }

# Create a singleton instance
ai_service = AIService()
