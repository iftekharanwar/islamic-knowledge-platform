from supabase import create_client, Client
import os
from dotenv import load_dotenv
import json
from typing import Dict, Any, Optional

load_dotenv()

class SupabaseClient:
    def __init__(self):
        self.url = "https://lewsapkmumthxkspsemo.supabase.co"
        self.key = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imxld3NhcGttdW10aHhrc3BzZW1vIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzMzNzMyNTIsImV4cCI6MjA0ODk0OTI1Mn0.tnYFIgUGwFi4hLGsQrWeeZkSeX6uKWKh5eU8VZT13NQ"
        self.client: Client = create_client(self.url, self.key)

    async def get_content(self, table_name: str = 'islamic_content', query: Optional[Dict[str, Any]] = None) -> list:
        try:
            data = self.client.table(table_name).select("*")
            if query:
                for key, value in query.items():
                    data = data.eq(key, value)
            result = data.execute()
            return result.data if result.data else []
        except Exception as e:
            print(f"Error getting content: {e}")
            return []

    async def insert_content(self, data: Dict[str, Any], table_name: str = 'islamic_content') -> Optional[Dict]:
        try:
            serialized_data = {
                k: v.value if hasattr(v, 'value') else v
                for k, v in data.items()
            }
            result = self.client.table(table_name).insert(serialized_data).execute()
            return result.data[0] if result.data else None
        except Exception as e:
            print(f"Error inserting content: {e}")
            return None

    async def search_content(self, search_term: str, table_name: str = 'islamic_content') -> list:
        try:
            result = self.client.table(table_name).select("*").textSearch("content", search_term).execute()
            return result.data if result.data else []
        except Exception as e:
            print(f"Error searching content: {e}")
            return []

# Create a singleton instance
supabase = SupabaseClient()
