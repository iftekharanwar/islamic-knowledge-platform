# Router initialization
