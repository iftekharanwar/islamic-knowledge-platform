from fastapi import APIRouter, HTTPException
from typing import Dict, List, Optional
from app.models.database import db, ContentType, Topic
from app.services.ai_service import ai_service
from pydantic import BaseModel

router = APIRouter(
    prefix="/knowledge",
    tags=["knowledge"],
    responses={404: {"description": "Not found"}},
)

class SearchRequest(BaseModel):
    query: str
    school_of_thought: Optional[str] = None

class SearchResponse(BaseModel):
    answer: str
    confidence: float
    references: List[Dict[str, Optional[str]]]  # Make reference fields optional
    source_type: Optional[str] = None

@router.post("/search", response_model=SearchResponse)
async def search_knowledge(request: SearchRequest):
    try:
        db_results = await db.search_content(request.query)
        ai_response = await ai_service.generate_response(request.query, context=db_results)

        return SearchResponse(
            answer=ai_response.get("answer", ""),
            confidence=ai_response.get("confidence", 0.0),
            references=ai_response.get("references", []),
            source_type=ai_response.get("source_type")
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/topics")
async def get_topics() -> Dict[str, List[str]]:
    return {"topics": [topic.value for topic in Topic]}

@router.get("/content/{content_type}")
async def get_content_by_type(
    content_type: ContentType,
    topic: Optional[Topic] = None,
) -> List[Dict]:
    try:
        content = await db.get_content(content_type, topic)
        if not content:
            raise HTTPException(status_code=404, detail="No content found")
        return content
    except HTTPException as he:
        raise he
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
