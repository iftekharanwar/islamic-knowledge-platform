INITIAL_CONTENT = [
    {
        "content_type": "quran",
        "topic": "aqeedah",
        "title": "The Nature of Allah",
        "content": "Say, 'He is Allah, [who is] One, Allah, the Eternal Refuge. He neither begets nor is born, Nor is there to Him any equivalent.' (Surah Al-Ikhlas 112:1-4)",
        "source": "Quran",
        "reference": "Surah Al-Ikhlas",
        "scholar": None
    },
    {
        "content_type": "hadith",
        "topic": "fiqh",
        "title": "The Five Pillars of Islam",
        "content": "Islam has been built upon five things – on testifying that there is no god save Allah, and that Muhammad is His Messenger; on performing salah; on giving the zakah; on Hajj to the House; and on fasting during Ramadan.",
        "source": "Sahih al-Bukhari",
        "reference": "Hadith 8",
        "scholar": "Imam Bukhari"
    },
    {
        "content_type": "fatwa",
        "topic": "fiqh",
        "title": "Digital Cryptocurrencies",
        "content": "The use of digital currencies must comply with Islamic principles of finance. They should have real value, be free from excessive uncertainty (gharar), and not involve usury (riba).",
        "source": "Contemporary Fatwa",
        "reference": "Islamic Fiqh Council",
        "scholar": "Contemporary Scholars"
    }
]
