import { ChakraProvider, Box, Container, extendTheme } from '@chakra-ui/react';
import Header from './components/layout/Header';
import ChatInterface from './components/ChatBot/ChatInterface';

const theme = extendTheme({
  styles: {
    global: {
      body: {
        bg: 'gray.50',
      },
    },
  },
});

function App() {
  return (
    <ChakraProvider theme={theme}>
      <Box minH="100vh" display="flex" flexDirection="column">
        <Header />
        <Container maxW="container.xl" flex="1" py={8}>
          <ChatInterface />
        </Container>
      </Box>
    </ChakraProvider>
  );
}

export default App;
