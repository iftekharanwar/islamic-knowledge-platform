import axios from 'axios';
import { API_ENDPOINTS } from '../config/api';

interface QueryResponse {
  answer: string;
  confidence: number;
  references: {
    type: string;
    source: string;
    reference: string;
    scholar?: string;
  }[];
}

export const queryKnowledgeBase = async (query: string): Promise<QueryResponse> => {
  try {
    const response = await axios.post(API_ENDPOINTS.KNOWLEDGE_BASE.QUERY, { query });
    return response.data;
  } catch (error) {
    if (axios.isAxiosError(error)) {
      throw new Error(error.response?.data?.message || 'Failed to query knowledge base');
    }
    throw error;
  }
};
